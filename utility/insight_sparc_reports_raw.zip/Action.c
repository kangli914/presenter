Action()
{

	lr_start_transaction("1_transaction_site");

	web_set_sockets_option("SSL_VERSION", "TLS1.2");

	web_set_max_html_param_len("431");

	web_url("rbcinsightbeta.rbc.com", 
		"URL=https://rbcinsightbeta.rbc.com/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		LAST);

	web_add_cookie("ak_bmsc=00759DB0807E6AF5BA90430DAAEA614B48F62BA8F01400001F4A7B5A11B42850~plPGSFgq3Rm0xA+NuJFa0z6qwxBMvhmkWPU3EHcw1nm+osQZYUImuIbNDMDqRJn4DUgwFWUNv5BaJcxB2WHUja+hg5i1sHnty/UvndiFmPQupsgvAqDwKUYMAk1ryzmxxV+OR2JU9e+wWE4/ziconoMcW+3ibPdecpczle7d4UFYtKTLCcjoz66OJW83KRKI9ldSRMopgmEMI3SU+4gOrs6uHSTKswEGud719wVvYSlJ8=; DOMAIN=rbcinsightbeta.rbc.com");

/*Correlation comment: Automatic rules - Do not change!  
Original value='00759DB0807E6AF5BA90430DAAEA614B48F62BA8F01400001F4A7B5A11B42850~pldlwfu0YhLNyJgGZ1T3XMtPh7tchWz1rOxrcVSQVDvaxsviwn1Z0NGaF1tKR8u3cNcTH9eqcaexd4+CQ1aFGHu6i6wDyMpF5gxopTx6hGFK86kBZU4kyDEqML9Ftc62pXxG6G4Bk/PXrlPv5I1AEOZYm1obbwmV5RZvGNqd5cCPLgJCXTcvd5k6Vg4CTTmuNsZxdF4OcJGgd5eTHakeiZ7SrnTRd5dzuNGqt6sBwnuac=' 
Name ='ak_bmsc' 
Type ='Rule' 
AppName ='Insight' 
RuleName ='ak_bmsc'*/
	web_reg_save_param_regexp(
		"ParamName=ak_bmsc",
		"RegExp=ak_bmsc=(.*?);",
		"Ordinal=1",
		SEARCH_FILTERS,
		"Scope=Cookies",
		"IgnoreRedirections=Yes",
		"RequestUrl=*/ui/*",
		LAST);

	web_url("ui", 
		"URL=https://rbcinsightbeta.rbc.com/ui?v=1518029344978", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://rbcinsightbeta.rbc.com/", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		LAST);

	web_add_cookie("ak_bmsc={ak_bmsc}; DOMAIN=rbcinsightbeta.rbc.com");

	web_add_cookie("ak_bmsc=00759DB0807E6AF5BA90430DAAEA614B48F62BA8F01400001F4A7B5A11B42850~plVet/guvBDCeheFVN2y9Rg/KoXrjTd8bxKv9F9bm/YCdx4hoRvTJwFRU4xJ9L4Aznai2lLUsMtmEwr3YYZ6BCwOBeHC4uJgy2ZkRbhN4erxR3ieZVEUd+X4TckjeeUBAbzuid6600JHhv3gcFdMCq0CIdVx2wK+1VLHaW8QDthbd5a9HCFU1RGGFUBqwfw3bAOFQ1msBL9nOo92xj5olMgl1GXyzHiPeg18KksUHgPR8=; DOMAIN=rbcinsightbeta.rbc.com");

	web_url("init.html", 
		"URL=https://rbcinsightbeta.rbc.com/ui/init.html?in=0&tv=1518029347548", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://rbcinsightbeta.rbc.com/ui/?v=1518029344978", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=manifest.appcache", "Referer=", ENDITEM, 
		"Url=styles.1e4eaf65e78eb80de657.bundle.css", "Referer=https://rbcinsightbeta.rbc.com/ui/init.html?in=0&tv=1518029347548", ENDITEM, 
		"Url=inline.8666330bb5094ce54b0e.bundle.js", "Referer=https://rbcinsightbeta.rbc.com/ui/init.html?in=0&tv=1518029347548", ENDITEM, 
		"Url=scripts.a1fbbafe9ca0c497e0b3.bundle.js", "Referer=https://rbcinsightbeta.rbc.com/ui/init.html?in=0&tv=1518029347548", ENDITEM, 
		"Url=polyfills.9d2d4331ac6314df9952.bundle.js", "Referer=https://rbcinsightbeta.rbc.com/ui/init.html?in=0&tv=1518029347548", ENDITEM, 
		"Url=main.176bce2889a01ff63842.bundle.js", "Referer=https://rbcinsightbeta.rbc.com/ui/init.html?in=0&tv=1518029347548", ENDITEM, 
		LAST);

	web_add_cookie("IV_JCT=%2Fui; DOMAIN=rbcinsightbeta.rbc.com");

	web_add_cookie("ak_bmsc=00759DB0807E6AF5BA90430DAAEA614B48F62BA8F01400001F4A7B5A11B42850~plTgyvPxo8luvBhPdGgPhkhWNVspo4B+dClJ6BJm6plL3/FH+qrqool8SMjL96w7Q5IacTm3XrgsLRRS0X6Zl/4el3lSM3gTc/SYcCE5nJKH8Jzh7z7Hw8WFM7XdKSzCTlBl9/EXmcabcRDhVdfuiJCP1hX8sQIRcu6wgDrP7E5kZWLDYCadLdSYHFP/19SH+8s/3nnXCcMzr1dAd+QeUV4CK4TIdM94TSYEkGkJ1grV4=; DOMAIN=rbcinsightbeta.rbc.com");

/*Correlation comment: Automatic rules - Do not change!  
Original value='00759DB0807E6AF5BA90430DAAEA614B48F62BA8F01400001F4A7B5A11B42850~plUaxja9yf5OP1wQ1O1m14MTXryK8Jh/n+aM//C6Hal16mPu5+saoEXkn4m+EUdV3ZkYzD/frNhbpeOaf+YFBU5xXsuMUzLt4iv/xrEHm2TluTurjJWCsWsdR5yEKoFTx8o1GqtmfLr48IPIKeS25DLyKfz6JatbPU3dQ+vP7UHv9oIfbBuatS8E/n6LOFxBoSrrIzkMxoNPJJhaN/d2hLyYf4X/JKvv2ubUR/zmbhUfmeowMgB7uZc6G/MQ5NI88T' 
Name ='ak_bmsc_1' 
Type ='Rule' 
AppName ='Insight' 
RuleName ='ak_bmsc'*/
	web_reg_save_param_regexp(
		"ParamName=ak_bmsc_1",
		"RegExp=ak_bmsc=(.*?);",
		"Ordinal=1",
		SEARCH_FILTERS,
		"Scope=Cookies",
		"RequestUrl=*/favicon.ico*",
		LAST);

	web_url("cache.html", 
		"URL=https://rbcinsightbeta.rbc.com/ui/cache.html", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://rbcinsightbeta.rbc.com/ui/init.html?in=0&tv=1518029347548", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=loading.c82062c113a7bcdafb57.gif", "Referer=https://rbcinsightbeta.rbc.com/ui/init.html?in=0&tv=1518029347548", ENDITEM, 
		"Url=vendor.73096d8574519f9cb454.bundle.js", "Referer=https://rbcinsightbeta.rbc.com/ui/init.html?in=0&tv=1518029347548", ENDITEM, 
		"Url=favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_add_cookie("ak_bmsc={ak_bmsc_1}; DOMAIN=rbcinsightbeta.rbc.com");

	web_add_cookie("TS01cc2b8b=0181cd863d616a34c5fed44ff2de3b1ebfaaa2fceb3329512893a659c76f48ca4a986f36e29d2e6a8fbbcc2a02c2eb9498bcb214623b2693a8d601fbd77eec6d3e80e9edbf; DOMAIN=rbcinsightbeta.rbc.com");

	web_add_cookie("PD-S-SESSION-ID=1_hV2wGseQD6W5JnlFRss4VeRdvARE7aQD1TGOPGKXiEqePRS9T+U=_AAAAAAA=_nqDKv72DTyC+S3BXJMKezetF4dA=; DOMAIN=rbcinsightbeta.rbc.com");

	web_add_cookie("TS015371d2=0181cd863dfff5de75f586f3f435f8a08eff5fc9a23329512893a659c76f48ca4a986f36e2d795d8a3e07428967db8edff1d8f5a5c5c452f44a6edf8060c474390aec3c60f; DOMAIN=rbcinsightbeta.rbc.com");

	web_add_cookie("ak_bmsc=00759DB0807E6AF5BA90430DAAEA614B48F62BA8F01400001F4A7B5A11B42850~plr7JmREQuTOGaHrt9XBV3W1y6S+TNA5onDabv7/4qreBrDTtC5JV85XrKz1/lS4aYrBM1XfNT0SDD7WjyblTc9+Eyl1TtqhDJ1jau3cbRqrmWDgBBanEfxMIf2puWPIfg53vAFoF2wiFnfGdsHX6UyKAKlKD5v9XS+AdQto0F2RJxh8zcKX4jZZp7bnZW9D4VzoMMyD4gsiiX3mr0hlclTMBWVRuRMAfpumvsB4Sunywa3RQVzh2nhDoCt1o/rzJ1; DOMAIN=rbcinsightbeta.rbc.com");

	web_add_auto_header("Origin", 
		"https://rbcinsightbeta.rbc.com");

/*Correlation comment: Automatic rules - Do not change!  
Original value='00759DB0807E6AF5BA90430DAAEA614B48F62BA8F01400001F4A7B5A11B42850~pl04TCgS1rTnT3XoW5jOJS4ZdCa8N0voePqibBp2CQo74uL62E6pjT40UidcOE+3tsJnnoePJTqr5I5aVktQk0CRLAIW/DFf56yd2UDrCFinYzAz/A3pTGGh4afTS302Z7osh/T2NyyiKbH/nSzmglRAgTrzC8SIDofaQjNb3/JMbhpBBX0fD7sA4jBy8R9DVBlsmYWAR2hRNERDFtb1KLHbxpkcguaHGqLcxonl9yQIg=' 
Name ='ak_bmsc_2' 
Type ='Rule' 
AppName ='Insight' 
RuleName ='ak_bmsc'*/
	web_reg_save_param_regexp(
		"ParamName=ak_bmsc_2",
		"RegExp=ak_bmsc=(.*?);",
		"Ordinal=1",
		SEARCH_FILTERS,
		"Scope=Cookies",
		LAST);

/*Correlation comment: Automatic rules - Do not change!  
Original value='00759DB0807E6AF5BA90430DAAEA614B48F62BA8F01400001F4A7B5A11B42850~pl7GbOa5v/GMBIBW4bUo5wzyq4amzMj5AskeCNiG5eIZYIcO+Po459w7sIL4XnfO4k3p37dsdJyO/I5njwy2IsELuYuDUUTVBtcVNfMuN5uAbhfBQWPxy//aLMRM+6zmv+3X3aTIXgWOtwSKH4qgQpDmr8JF/5DMXRFSk8SISbFWurKJht+mheq6JGCE63PZdOVNyRbYtdeXLyYrYDX3fC9e0gNnNLvHgncnAhZy1rFrs=' 
Name ='ak_bmsc_3' 
Type ='Rule' 
AppName ='Insight' 
RuleName ='ak_bmsc'*/
	web_reg_save_param_regexp(
		"ParamName=ak_bmsc_3",
		"RegExp=ak_bmsc=(.*?);",
		"Ordinal=1",
		SEARCH_FILTERS,
		"Scope=Cookies",
		"RequestUrl=*/Roboto-Regular-webfont.woff*",
		LAST);

/*Correlation comment: Automatic rules - Do not change!  
Original value='00759DB0807E6AF5BA90430DAAEA614B48F62BA8F01400001F4A7B5A11B42850~plag60nVYQYh1OH5oSqk3sOrHYiL++lpzLSDljCaFMZ5EXNQycyM5sd/ig+R+Wq9YsmslfEGuFipMh4zWRikUOQze5enCZce4VUvAVqH+torrtQWXdrgBAi1OeWrtvjVCDqnNX8TKsGQYgqX3R7Njargxk0cP+dVqHFdAPvnFRsIXyenHH+C4XNhRlqy5eHy/3lG94yn3shZfirOYX8RZOXzWWQktKlPlx9tXY7DzlBoM=' 
Name ='ak_bmsc_4' 
Type ='Rule' 
AppName ='Insight' 
RuleName ='ak_bmsc'*/
	web_reg_save_param_regexp(
		"ParamName=ak_bmsc_4",
		"RegExp=ak_bmsc=(.*?);",
		"Ordinal=1",
		SEARCH_FILTERS,
		"Scope=Cookies",
		"RequestUrl=*/Roboto-Light-webfont.woff*",
		LAST);

/*Correlation comment: Automatic rules - Do not change!  
Original value='00759DB0807E6AF5BA90430DAAEA614B48F62BA8F01400001F4A7B5A11B42850~pl85oReeviNA3IFiagSbSYmmr5X1ReKElm9zQqluybrvYa9M2bJElNtPvVXA63g40nO+Jz3AxjKm/ZyrDcpcPNb9MWC8TdhchQp2RICr+gFVezhH7zebiQAPg2iKHMYEHD9klyRFisK7vV8ggtaDY5xlLiYSs+wUiPb1srFHqoWadecPFdC+Wxhux4rS2L0NAiXcZ6f5MetflDhOavNrUCV9XGej6Gp89vrjpPYkx11WA=' 
Name ='ak_bmsc_5' 
Type ='Rule' 
AppName ='Insight' 
RuleName ='ak_bmsc'*/
	web_reg_save_param_regexp(
		"ParamName=ak_bmsc_5",
		"RegExp=ak_bmsc=(.*?);",
		"Ordinal=1",
		SEARCH_FILTERS,
		"Scope=Cookies",
		"RequestUrl=*/fontawesome-webfont.woff2*",
		LAST);

	web_custom_request("device", 
		"URL=https://rbcinsightbeta.rbc.com/services/unauth/device", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://rbcinsightbeta.rbc.com/ui/auth", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\n  \"timeZone\": \"America/Toronto\"\n}", 
		EXTRARES, 
		"Url=/ui/7.b65a2bdb0aefa365f6ff.chunk.js", "Referer=https://rbcinsightbeta.rbc.com/ui/auth", ENDITEM, 
		"Url=/ui/favicon.ico", "Referer=", ENDITEM, 
		"Url=/ui/0.a85a6ca6a5b3cc90750c.chunk.js", "Referer=https://rbcinsightbeta.rbc.com/ui/auth", ENDITEM, 
		"Url=/assets/stylesheets/fonts/Regular/Roboto-Regular-webfont.woff?i=1", "Referer=https://rbcinsightbeta.rbc.com/ui/init.html?in=0&tv=1518029347548", ENDITEM, 
		"Url=/assets/stylesheets/fonts/Light/Roboto-Light-webfont.woff?i=1", "Referer=https://rbcinsightbeta.rbc.com/ui/init.html?in=0&tv=1518029347548", ENDITEM, 
		"Url=/ui/Logo_capital_markets.1213b6621dfd0ef82865.jpg", "Referer=https://rbcinsightbeta.rbc.com/ui/login/identifyUrself", ENDITEM, 
		"Url=/assets/stylesheets/fonts/fontawesome-webfont.woff2?v=4.7.0&i=1", "Referer=https://rbcinsightbeta.rbc.com/ui/init.html?in=0&tv=1518029347548", ENDITEM, 
		LAST);

	lr_end_transaction("1_transaction_site",LR_AUTO);

	lr_start_transaction("2_transaction_email");

	/*Possible OAUTH authorization was detected. It is recommended to correlate the authorization parameters.*/

	web_add_cookie("PD-S-SESSION-ID=1_hV2wGseQD6W5JnlFRss4VeRdvARE7aQD1TGOPGKXiEqePRS9T+U=_AAAAAQA=_nqDKv72DTyC+S3BXJMKezetF4dA=; DOMAIN=rbcinsightbeta.rbc.com");

	web_add_cookie("TS015371d2=0181cd863d0cad0e34befec00587021b01259592e93329512893a659c76f48ca4a986f36e21817ab41e5f4f664e16fa94d64554d34935713e5459961a382c1fd0d0c74558c; DOMAIN=rbcinsightbeta.rbc.com");

	web_add_header("DEVICE_NICKNAME", 
		"Mobile Safari");

	web_add_header("EMAIL_ADDRESS", 
		"Kurt.Hallead@rbccm.com");

	lr_think_time(48);

/*Correlation comment: Automatic rules - Do not change!  
Original value='00759DB0807E6AF5BA90430DAAEA614B48F62BA8F01400001F4A7B5A11B42850~plxBkota/ZDFjoPMsxqFYADVkByBuypPohK2Dve+eqfouDwXZIQGKyOsCh83UwMuKR0h1gyMWOxq3ZpBPhxwicisRPKehH06n21mj2MdIdsYfcCu40PARo2JT125YovFw6+x9pNqjac+OQ4V3C/gYGaKX/6TnfIVPevmBCSrhEEkWtCVw591V4WxND+0lsF5ZrACE+qmSL5CM9KVSFiTVpdwA0knMAy0bQgufj+Os2Rak=' 
Name ='ak_bmsc_6' 
Type ='Rule' 
AppName ='Insight' 
RuleName ='ak_bmsc'*/
	web_reg_save_param_regexp(
		"ParamName=ak_bmsc_6",
		"RegExp=ak_bmsc=(.*?);",
		"Ordinal=1",
		SEARCH_FILTERS,
		"Scope=Cookies",
		LAST);

/*Correlation comment: Automatic rules - Do not change!  
Original value='00759DB0807E6AF5BA90430DAAEA614B48F62BA8F01400001F4A7B5A11B42850~plfZ/+vGa56m5tUz3S1hE7S0g1Qdva96QZ8ttOz2IUPVtPyy4rTLp+wM4mmyypKGeWlIauaWwGCcixO4mxpjiCkckBNq99TmbFXTohXrl+I8wU1+1cYISNiVJT5YLJFQbXWF5yQEDHZ1Vrnf5nnymmLRZ9Mf+g41HB/n3RXc42VqffKtNvIYHudC9/XU/vSc81QGYWkD1535cQtqPd+FgFNcSjZTzUgZv4CS0HC0MyT83voDnXgXUxpQQK6jvObuot' 
Name ='ak_bmsc_7' 
Type ='Rule' 
AppName ='Insight' 
RuleName ='ak_bmsc'*/
	web_reg_save_param_regexp(
		"ParamName=ak_bmsc_7",
		"RegExp=ak_bmsc=(.*?);",
		"Ordinal=1",
		SEARCH_FILTERS,
		"Scope=Cookies",
		"RequestUrl=*/glyphicons-halflings-regular.448c34a56d699c29117a.woff2*",
		LAST);

	web_custom_request("email", 
		"URL=https://rbcinsightbeta.rbc.com/services/auth/email", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://rbcinsightbeta.rbc.com/ui/login/identifyUrself", 
		"Snapshot=t16.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={}", 
		EXTRARES, 
		"Url=/ui/glyphicons-halflings-regular.448c34a56d699c29117a.woff2", "Referer=https://rbcinsightbeta.rbc.com/ui/init.html?in=0&tv=1518029347548", ENDITEM, 
		LAST);

	lr_end_transaction("2_transaction_email",LR_AUTO);

	lr_start_transaction("3_transaction_key2Dashboard");

	web_add_cookie("ak_bmsc={ak_bmsc_6}; DOMAIN=rbcinsightbeta.rbc.com");

	web_revert_auto_header("Origin");

	web_add_header("X-Requested-With", 
		"XMLHttpRequest");

	lr_think_time(36);

/*Correlation comment: Automatic rules - Do not change!  
Original value='00759DB0807E6AF5BA90430DAAEA614B48F62BA8F01400001F4A7B5A11B42850~plqsGl1c254rgi1uW3GZahkN9sFOMp/vWlITZxpdkiXSOyQ7NIPYqINgx3WN+3OVkNWJHk885tiQ+uI+Skh483koOBFxiPHghdNtOuJ0kZPGFCBcsib4C1mzJ2bNFM1ohO9uNEA6iYU0YopFBZKf0yHbBG0Tezef2WW//PUFrrYxgVllvctlLttx6S1a21zTEQUgVT1o9egE8UmVnQv3mx2d5mV84iMv7gBgH7L14W9So=' 
Name ='ak_bmsc_8' 
Type ='Rule' 
AppName ='Insight' 
RuleName ='ak_bmsc'*/
	web_reg_save_param_regexp(
		"ParamName=ak_bmsc_8",
		"RegExp=ak_bmsc=(.*?);",
		"Ordinal=1",
		SEARCH_FILTERS,
		"Scope=Cookies",
		LAST);

	web_custom_request("healthcheck", 
		"URL=https://rbcinsightbeta.rbc.com/services/auth/healthcheck?tv=1518029470881", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://rbcinsightbeta.rbc.com/ui/login/authenticateUser", 
		"Snapshot=t17.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		LAST);

	web_add_cookie("ak_bmsc={ak_bmsc_8}; DOMAIN=rbcinsightbeta.rbc.com");

	web_add_cookie("ak_bmsc={ak_bmsc_7}; DOMAIN=rbcinsightbeta.rbc.com");

	web_add_cookie("PD-S-SESSION-ID=1_hV2wGseQD6W5JnlFRss4VeRdvARE7aQD1TGOPGKXiEqePRS9T+U=_AAAAAgA=_nqDKv72DTyC+S3BXJMKezetF4dA=; DOMAIN=rbcinsightbeta.rbc.com");

	web_add_cookie("TS015371d2=0181cd863dd9c57848489269f0890c69e616f9633d3329512893a659c76f48ca4a986f36e2db4fc9eb865bc352b44d8e36e79e6340fcbe34cb6cf6f63b1b9f5f08f4a07e3c; DOMAIN=rbcinsightbeta.rbc.com");

	web_add_header("ACCESS_KEY", 
		"11111111");

	web_add_header("DEVICE_NICKNAME", 
		"KH - Mobile Safari1199");

	web_add_header("Origin", 
		"https://rbcinsightbeta.rbc.com");

	lr_think_time(19);

	web_custom_request("accesskey", 
		"URL=https://rbcinsightbeta.rbc.com/services/auth/accesskey", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://rbcinsightbeta.rbc.com/ui/login/authenticateUser", 
		"Snapshot=t18.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\n  \"timeZone\": \"America/Toronto\"\n}", 
		EXTRARES, 
		"Url=/ui/6.aac6cad0361159f5d4f2.chunk.js", "Referer=https://rbcinsightbeta.rbc.com/ui/login/authenticateUser", ENDITEM, 
		LAST);

	web_add_header("iv-user", 
		"Kurt.Hallead@rbccm.com");

	web_url("list", 
		"URL=https://rbcinsightbeta.rbc.com/services/common/banner/list?tv=1518029491765", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://rbcinsightbeta.rbc.com/ui/main/dashboard", 
		"Snapshot=t19.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/ui/assets/resources/images/Logo_capital_markets.jpg", "Referer=https://rbcinsightbeta.rbc.com/ui/main/dashboard", ENDITEM, 
		LAST);

/*Correlation comment: Automatic rules - Do not change!  
Original value='00759DB0807E6AF5BA90430DAAEA614B48F62BA8F01400001F4A7B5A11B42850~plHy2XWjH4tTjV6qeQctCHQdTRFqodoGnHsngR0mMcjAF0JlPJStdvA9lxBkvXqECZypNa9Bh2pUzCE3564SdWlaSWLqYJH/xQibvyYmqxSMNUcKSvMyzztTE6U5JYSfDh/RHy2xOKlGpAllHcCEienfqlaqKbMRAzOnVwZq6ATScMALaC5KkOtH5eKZnVuG9ME1yG6fDFlozFaZuiBptmkp7NN8mITh6sD0yF3R9Ix2c=' 
Name ='ak_bmsc_9' 
Type ='Rule' 
AppName ='Insight' 
RuleName ='ak_bmsc'*/
	web_reg_save_param_regexp(
		"ParamName=ak_bmsc_9",
		"RegExp=ak_bmsc=(.*?);",
		"Ordinal=1",
		SEARCH_FILTERS,
		"Scope=Cookies",
		LAST);

	web_url("frequentanalyst", 
		"URL=https://rbcinsightbeta.rbc.com/services/gresearch/frequentanalyst?tv=1518029491731", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://rbcinsightbeta.rbc.com/ui/main/dashboard", 
		"Snapshot=t20.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/ui/assets/resources/images/ProfileIcon.png", "Referer=https://rbcinsightbeta.rbc.com/ui/main/dashboard", ENDITEM, 
		"Url=/ui/searchpane-3.3ea695f6dbea633dd655.jpg", "Referer=https://rbcinsightbeta.rbc.com/ui/main/dashboard", ENDITEM, 
		LAST);

	web_add_auto_header("Origin", 
		"https://rbcinsightbeta.rbc.com");

	web_custom_request("data", 
		"URL=https://rbcinsightbeta.rbc.com/services/research/event/data?tv=1518029491846", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://rbcinsightbeta.rbc.com/ui/main/dashboard", 
		"Snapshot=t21.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\n  \"pageIndex\": 0,\n  \"batchSize\": 5,\n  \"eventSearchCriteria\": {\n    \"eventTypeList\": null,\n    \"locationList\": null,\n    \"regionIdList\": null,\n    \"fromDate\": \"7/2/2018\",\n    \"sortBy\": 0,\n    \"sortType\": 1\n  }\n}", 
		LAST);

/* Added by Async CodeGen.
ID=Poll_0
ScanType = Recording

The following URLs are considered part of this conversation:
	https://rbcinsightbeta.rbc.com/services/gresearch/module/data?tv=1518029491889
	https://rbcinsightbeta.rbc.com/services/gresearch/module/data?tv=1518029491891
	https://rbcinsightbeta.rbc.com/services/gresearch/module/data?tv=1518029491887
	https://rbcinsightbeta.rbc.com/services/gresearch/module/data?tv=1518029491893
	https://rbcinsightbeta.rbc.com/services/gresearch/module/data?tv=1518029491896

TODO - The following callbacks have been added to AsyncCallbacks.c.
Add your code to the callback implementations as necessary.
	Poll_0_RequestCB
	Poll_0_ResponseCB
 */
	web_reg_async_attributes("ID=Poll_0", 
		"Pattern=Poll", 
		"URL=https://rbcinsightbeta.rbc.com/services/gresearch/module/data?tv=1518029491889", 
		"PollIntervalMs=400", 
		"RequestCB=Poll_0_RequestCB", 
		"ResponseCB=Poll_0_ResponseCB", 
		LAST);

	web_custom_request("data_2", 
		"URL=https://rbcinsightbeta.rbc.com/services/gresearch/module/data?tv=1518029491889", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://rbcinsightbeta.rbc.com/ui/main/dashboard", 
		"Snapshot=t22.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\n  \"pageIndex\": 0,\n  \"batchSize\": 5,\n  \"researchModuleId\": 6380,\n  \"searchCriteria\": {\n    \"dateRange\": 1,\n    \"fromDate\": null,\n    \"toDate\": null,\n    \"reportType\": 1,\n    \"contentType\": 0,\n    \"sortBy\": 4,\n    \"sortType\": 2,\n    \"keywordText\": \"\",\n    \"keywordSearchType\": 1,\n    \"actionType\": []\n  }\n}", 
		LAST);

	web_add_cookie("ak_bmsc={ak_bmsc_3}; DOMAIN=rbcinsightbeta.rbc.com");

	web_add_cookie("ak_bmsc={ak_bmsc_5}; DOMAIN=rbcinsightbeta.rbc.com");

/* Removed by Async CodeGen.
ID = Poll_0
 */
	/*
 web_custom_request("data_3",
		"URL=https://rbcinsightbeta.rbc.com/services/gresearch/module/data?tv=1518029491891",
		"Method=POST",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=https://rbcinsightbeta.rbc.com/ui/main/dashboard",
		"Snapshot=t23.inf",
		"Mode=HTML",
		"EncType=application/json",
		"Body={\n"
		"  \"pageIndex\": 0,\n"
		"  \"batchSize\": 5,\n"
		"  \"researchModuleId\": 6381,\n"
		"  \"searchCriteria\": {\n"
		"    \"dateRange\": 1,\n"
		"    \"fromDate\": null,\n"
		"    \"toDate\": null,\n"
		"    \"reportType\": 1,\n"
		"    \"contentType\": 0,\n"
		"    \"sortBy\": 4,\n"
		"    \"sortType\": 2,\n"
		"    \"keywordText\": \"\",\n"
		"    \"keywordSearchType\": 1,\n"
		"    \"actionType\": []\n"
		"  }\n"
		"}",
		EXTRARES,
		"URL=/assets/stylesheets/fonts/Regular/Roboto-Medium-webfont.woff?i=1", "Referer=https://rbcinsightbeta.rbc.com/ui/init.html?in=0&tv=1518029347548", ENDITEM,
		LAST); 
	*/

/* Removed by Async CodeGen.
ID = Poll_0
 */
	/*
 web_custom_request("data_4",
		"URL=https://rbcinsightbeta.rbc.com/services/gresearch/module/data?tv=1518029491887",
		"Method=POST",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=https://rbcinsightbeta.rbc.com/ui/main/dashboard",
		"Snapshot=t24.inf",
		"Mode=HTML",
		"EncType=application/json",
		"Body={\n"
		"  \"pageIndex\": 0,\n"
		"  \"batchSize\": 5,\n"
		"  \"researchModuleId\": 6378,\n"
		"  \"searchCriteria\": {\n"
		"    \"dateRange\": 1,\n"
		"    \"fromDate\": null,\n"
		"    \"toDate\": null,\n"
		"    \"reportType\": 1,\n"
		"    \"contentType\": 0,\n"
		"    \"sortBy\": 4,\n"
		"    \"sortType\": 2,\n"
		"    \"keywordText\": \"\",\n"
		"    \"keywordSearchType\": 1,\n"
		"    \"actionType\": []\n"
		"  }\n"
		"}",
		LAST); 
	*/

	web_add_cookie("ak_bmsc={ak_bmsc_9}; DOMAIN=rbcinsightbeta.rbc.com");

/* Removed by Async CodeGen.
ID = Poll_0
 */
	/*
 web_custom_request("data_5",
		"URL=https://rbcinsightbeta.rbc.com/services/gresearch/module/data?tv=1518029491893",
		"Method=POST",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=https://rbcinsightbeta.rbc.com/ui/main/dashboard",
		"Snapshot=t25.inf",
		"Mode=HTML",
		"EncType=application/json",
		"Body={\n"
		"  \"pageIndex\": 0,\n"
		"  \"batchSize\": 5,\n"
		"  \"researchModuleId\": 6384,\n"
		"  \"searchCriteria\": {\n"
		"    \"dateRange\": 1,\n"
		"    \"fromDate\": null,\n"
		"    \"toDate\": null,\n"
		"    \"reportType\": 1,\n"
		"    \"contentType\": 0,\n"
		"    \"sortBy\": 4,\n"
		"    \"sortType\": 2,\n"
		"    \"keywordText\": \"\",\n"
		"    \"keywordSearchType\": 1,\n"
		"    \"actionType\": []\n"
		"  }\n"
		"}",
		LAST); 
	*/

	web_add_cookie("ak_bmsc=00759DB0807E6AF5BA90430DAAEA614B48F62BA8F01400001F4A7B5A11B42850~pl+hAblAnY0uMioxvHNvrRWGapMxNXgjPqW/MxI7I2cNzXmcZ1fkzEN8RFfWKSEQAxSIyqS8W27gni864+A4i1DyZEvJpuL/UClCVNUUzgfqy/LwgzAy+d3ovsbDsAzKhLCPLhoVaK45VkXHmFDce2/yhVH7kSeg+09SX3x6JqG0KUdfAj/YAoHBJyxXaB5yK1PfyWCBpfcTf9m+PeuqSPUS9QisMBt+y1TWO9LfkliUA=; DOMAIN=rbcinsightbeta.rbc.com");

/* Removed by Async CodeGen.
ID = Poll_0
 */
	/*
 web_custom_request("data_6",
		"URL=https://rbcinsightbeta.rbc.com/services/gresearch/module/data?tv=1518029491896",
		"Method=POST",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=https://rbcinsightbeta.rbc.com/ui/main/dashboard",
		"Snapshot=t26.inf",
		"Mode=HTML",
		"EncType=application/json",
		"Body={\n"
		"  \"pageIndex\": 0,\n"
		"  \"batchSize\": 5,\n"
		"  \"researchModuleId\": 6389,\n"
		"  \"searchCriteria\": {\n"
		"    \"dateRange\": 1,\n"
		"    \"fromDate\": null,\n"
		"    \"toDate\": null,\n"
		"    \"reportType\": 1,\n"
		"    \"contentType\": 0,\n"
		"    \"sortBy\": 4,\n"
		"    \"sortType\": 2,\n"
		"    \"keywordText\": \"\",\n"
		"    \"keywordSearchType\": 1,\n"
		"    \"actionType\": []\n"
		"  }\n"
		"}",
		EXTRARES,
		"URL=/services/common/bannerimages/3.png?nocache=1518029491737", "Referer=https://rbcinsightbeta.rbc.com/ui/main/dashboard", ENDITEM,
		"URL=/assets/stylesheets/fonts/Regular/FiraSans-Regular.woff2?i=1", "Referer=https://rbcinsightbeta.rbc.com/ui/init.html?in=0&tv=1518029347548", ENDITEM,
		"URL=/services/common/bannerimages/2.png?nocache=1518029491737", "Referer=https://rbcinsightbeta.rbc.com/ui/main/dashboard", ENDITEM,
		"URL=/services/common/bannerimages/17.png?nocache=1518029491737", "Referer=https://rbcinsightbeta.rbc.com/ui/main/dashboard", ENDITEM,
		LAST); 
	*/

/* Added by Async CodeGen.
ID = Poll_0
 */
	web_stop_async("ID=Poll_0", 
		LAST);

	web_custom_request("data_7", 
		"URL=https://rbcinsightbeta.rbc.com/services/gresearch/module/data?tv=1518029491885", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://rbcinsightbeta.rbc.com/ui/main/dashboard", 
		"Snapshot=t27.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\n  \"pageIndex\": 0,\n  \"batchSize\": 5,\n  \"researchModuleId\": 6376,\n  \"searchCriteria\": {\n    \"dateRange\": 1,\n    \"fromDate\": null,\n    \"toDate\": null,\n    \"reportType\": 1,\n    \"contentType\": 0,\n    \"sortBy\": 4,\n    \"sortType\": 2,\n    \"keywordText\": \"\",\n    \"keywordSearchType\": 1,\n    \"actionType\": []\n  }\n}", 
		LAST);

	web_custom_request("data_8", 
		"URL=https://rbcinsightbeta.rbc.com/services/gresearch/module/data?tv=1518029491894", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://rbcinsightbeta.rbc.com/ui/main/dashboard", 
		"Snapshot=t28.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\n  \"pageIndex\": 0,\n  \"batchSize\": 5,\n  \"researchModuleId\": 6386,\n  \"searchCriteria\": {\n    \"dateRange\": 1,\n    \"fromDate\": null,\n    \"toDate\": null,\n    \"reportType\": 1,\n    \"contentType\": 0,\n    \"sortBy\": 4,\n    \"sortType\": 2,\n    \"keywordText\": \"\",\n    \"keywordSearchType\": 1,\n    \"actionType\": []\n  }\n}", 
		EXTRARES, 
		"Url=/ui/assets/resources/images/trending.gif", "Referer=https://rbcinsightbeta.rbc.com/ui/main/dashboard", ENDITEM, 
		LAST);

	lr_end_transaction("3_transaction_key2Dashboard",LR_AUTO);

	lr_start_transaction("4_transaction_sparc_report");

	web_revert_auto_header("Origin");

	web_add_cookie("ak_bmsc=00759DB0807E6AF5BA90430DAAEA614B48F62BA8F01400001F4A7B5A11B42850~plJAhYu8wAMNHlVrDQdGFhRjGqx+sWPJo7JbCnrCup9U880bIUaG3CDGw/9JAPqfiIDtmtHUCmznWjJA+pjWzPkSWLg8V0F+oEiqPDfaJWWF+rk9VIdvBQ7VIpG3QnH/Wi+ErgqJSXAN5a54mMKA+ewIp+SWprRfTJBatsnyLE0sI8m28KKxtPS2dRovIWHAZFM9W1M/oF6cfRYjccJuYxJf5Qkc0b9kAZ1chv84McYQzZv4Sbdyd45XXfs4V16xBg; DOMAIN=rbcinsightbeta.rbc.com");

	web_url("85997", 
		"URL=https://rbcinsightbeta.rbc.com/ui/main/report/85997", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t29.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/ui/inline.8666330bb5094ce54b0e.bundle.js", "Referer=https://rbcinsightbeta.rbc.com/ui/init.html?tv=1518029539410&prp=/main/report/85997", ENDITEM, 
		"Url=/ui/styles.1e4eaf65e78eb80de657.bundle.css", "Referer=https://rbcinsightbeta.rbc.com/ui/init.html?tv=1518029539410&prp=/main/report/85997", ENDITEM, 
		"Url=/ui/polyfills.9d2d4331ac6314df9952.bundle.js", "Referer=https://rbcinsightbeta.rbc.com/ui/init.html?tv=1518029539410&prp=/main/report/85997", ENDITEM, 
		"Url=/ui/main.176bce2889a01ff63842.bundle.js", "Referer=https://rbcinsightbeta.rbc.com/ui/init.html?tv=1518029539410&prp=/main/report/85997", ENDITEM, 
		"Url=/ui/scripts.a1fbbafe9ca0c497e0b3.bundle.js", "Referer=https://rbcinsightbeta.rbc.com/ui/init.html?tv=1518029539410&prp=/main/report/85997", ENDITEM, 
		"Url=/ui/manifest.appcache", "Referer=", ENDITEM, 
		"Url=/ui/vendor.73096d8574519f9cb454.bundle.js", "Referer=https://rbcinsightbeta.rbc.com/ui/init.html?tv=1518029539410&prp=/main/report/85997", ENDITEM, 
		LAST);

/*Correlation comment: Automatic rules - Do not change!  
Original value='00759DB0807E6AF5BA90430DAAEA614B48F62BA8F01400001F4A7B5A11B42850~plQdHsyidschfVHwrD30XMLgUs9jhiD4vt3jw9/bDQFG2g3Yx/5SzMM9L0RBcTJznReqJb/P3t6XqiZpKInDja8vvFgJZ4ltbgYhtNJiwNPZoasry1fHr3DJ7kEnfUejU0iai99QC0cA96NzZMTI6OBYRsydW40NlXF5pRaIs5WfO9Ppni0a3jR57EpTC5RQahtS1CffTUJ1xp3eQeWDOf82YugUfLSthOl11MUFOdbhV9WMW5naS4tbceOkIxmZt0' 
Name ='ak_bmsc_10' 
Type ='Rule' 
AppName ='Insight' 
RuleName ='ak_bmsc'*/
	web_reg_save_param_regexp(
		"ParamName=ak_bmsc_10",
		"RegExp=ak_bmsc=(.*?);",
		"Ordinal=1",
		SEARCH_FILTERS,
		"Scope=Cookies",
		LAST);

	web_url("cache.html_2", 
		"URL=https://rbcinsightbeta.rbc.com/ui/cache.html", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://rbcinsightbeta.rbc.com/ui/init.html?tv=1518029539410&prp=/main/report/85997", 
		"Snapshot=t30.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=loading.c82062c113a7bcdafb57.gif", "Referer=https://rbcinsightbeta.rbc.com/ui/404?tv=1518029539410&prp=%2Fmain%2Freport%2F85997", ENDITEM, 
		LAST);

	web_add_cookie("ak_bmsc={ak_bmsc_2}; DOMAIN=rbcinsightbeta.rbc.com");

	web_add_cookie("ak_bmsc={ak_bmsc_10}; DOMAIN=rbcinsightbeta.rbc.com");

	web_add_cookie("ak_bmsc=00759DB0807E6AF5BA90430DAAEA614B48F62BA8F01400001F4A7B5A11B42850~plFv0Ty8bWibZoqX95+iqQvGynBOqXc++RjUPLM0BX6IY3NAUK0SRQxWDT+bQOwAEpZ0GmVxcL4/4cnjeBSadWj2LAP4AkoIT11+I3YLxVPJAKn/Fr1piiMEK8a9IeHBtqIfyDU8Vo70DNyDKNtjliiP0Kvq/biRznEd2SJdwFDT5urpAplkKwqXOYIfMZ6TljCmkqR/EELVr3cr5xvg4RK14nwHCwLMRLivj/JIvi+PuWKsQ63rRzUKW1lAaI7qqt; DOMAIN=rbcinsightbeta.rbc.com");

	web_add_auto_header("Origin", 
		"https://rbcinsightbeta.rbc.com");

	web_custom_request("device_2", 
		"URL=https://rbcinsightbeta.rbc.com/services/unauth/device", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://rbcinsightbeta.rbc.com/ui/auth", 
		"Snapshot=t31.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\n  \"timeZone\": \"America/Toronto\"\n}", 
		EXTRARES, 
		"Url=/ui/favicon.ico", "Referer=", ENDITEM, 
		"Url=/ui/6.aac6cad0361159f5d4f2.chunk.js", "Referer=https://rbcinsightbeta.rbc.com/ui/auth", ENDITEM, 
		"Url=/ui/0.a85a6ca6a5b3cc90750c.chunk.js", "Referer=https://rbcinsightbeta.rbc.com/ui/auth", ENDITEM, 
		"Url=/ui/1.c7a66f2657c3a9a93cb2.chunk.js", "Referer=https://rbcinsightbeta.rbc.com/ui/auth", ENDITEM, 
		LAST);

	web_add_cookie("ak_bmsc=00759DB0807E6AF5BA90430DAAEA614B48F62BA8F01400001F4A7B5A11B42850~pl6jcHzVOg3JpZ16xBBKQdYfIvnK10hKClRHIvm6HF3rwJWZQgz0wox+y5bx3OGNt5N+tMP2rFAbOH8IP+FTg4tUGXdB7kNczIdPtYTXzenYLEx00QDiAxp0QnmUE0pNU1Pq3//lvn+7F5gfs/AJtJjX/7DxyZAhg/bFv3Zw2mUxZLkx2VTe2r/+wiNfzZKrygo5W+enFO/Dcv5kLG877njL84hrs4aUDEL2DhBjIDBzg=; DOMAIN=rbcinsightbeta.rbc.com");

/*Correlation comment: Automatic rules - Do not change!  
Original value='00759DB0807E6AF5BA90430DAAEA614B48F62BA8F01400001F4A7B5A11B42850~pl0loFMb08snU5asbw58VlNer77cd83CgjhKkyf6AXID6oPLgEcdmyFvnQGj+SwFDYm6atArDyQgQ4+20s6nuIHhgyKyOrOYGJIM3QY5P2UY92KZzqhYh/Rr8bq7G0LcSsoTVJlKB0K8SLi3XSDmJ6RYbRUad48KUoYSxAGUHVFiSWVEGr5HrL6hBuegGq5D+MGhBEZH2u8c0FUeAda2Imbps5eRQQRcLQF7ia7ju1LF8=' 
Name ='ak_bmsc_11' 
Type ='Rule' 
AppName ='Insight' 
RuleName ='ak_bmsc'*/
	web_reg_save_param_regexp(
		"ParamName=ak_bmsc_11",
		"RegExp=ak_bmsc=(.*?);",
		"Ordinal=1",
		SEARCH_FILTERS,
		"Scope=Cookies",
		"RequestUrl=*/fontawesome-webfont.woff2*",
		LAST);

/*Correlation comment: Automatic rules - Do not change!  
Original value='00759DB0807E6AF5BA90430DAAEA614B48F62BA8F01400001F4A7B5A11B42850~plqqzcdm5ssBMQHSkpEz/gLCWxdlqp0j7ziA8OSi0xrdtNB/hHM4PAh/J5yAJCSRoJqbZIyU2HI9BWk9PFKS9FG72EuXnLxObA3NaroNHF5klmzcfOMjjPPB18Gr0CkOfkzYwZamJ5SkqZXvB22NpofNgc5evnNx7I5eQHGI7NYoow0ni1PAOERNbwzuLaNi6hvmKKV2uUougt5nrmtj/BOE7RkrZ9C+9B6O2rv9BWzeE=' 
Name ='ak_bmsc_12' 
Type ='Rule' 
AppName ='Insight' 
RuleName ='ak_bmsc'*/
	web_reg_save_param_regexp(
		"ParamName=ak_bmsc_12",
		"RegExp=ak_bmsc=(.*?);",
		"Ordinal=1",
		SEARCH_FILTERS,
		"Scope=Cookies",
		"RequestUrl=*/Roboto-Medium-webfont.woff*",
		LAST);

	web_custom_request("null", 
		"URL=https://rbcinsightbeta.rbc.com/services/research/metadata/85997/0/null?tv=1518029556170", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://rbcinsightbeta.rbc.com/ui/auth", 
		"Snapshot=t32.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={}", 
		EXTRARES, 
		"Url=/ui/searchpane-3.3ea695f6dbea633dd655.jpg", "Referer=https://rbcinsightbeta.rbc.com/ui/main/report/85997", ENDITEM, 
		"Url=/assets/stylesheets/fonts/fontawesome-webfont.woff2?v=4.7.0&i=1", "Referer=https://rbcinsightbeta.rbc.com/ui/404?tv=1518029539410&prp=%2Fmain%2Freport%2F85997", ENDITEM, 
		"Url=/assets/stylesheets/fonts/Regular/Roboto-Medium-webfont.woff?i=1", "Referer=https://rbcinsightbeta.rbc.com/ui/404?tv=1518029539410&prp=%2Fmain%2Freport%2F85997", ENDITEM, 
		"Url=/ui/assets/resources/images/Logo_capital_markets.jpg", "Referer=https://rbcinsightbeta.rbc.com/ui/main/report/85997", ENDITEM, 
		LAST);

	web_revert_auto_header("Origin");

	web_url("85997_2", 
		"URL=https://rbcinsightbeta.rbc.com/services/gresearch/recommended/data/85997?tv=1518029557824", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://rbcinsightbeta.rbc.com/ui/main/report/85997", 
		"Snapshot=t33.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/assets/stylesheets/fonts/Regular/Roboto-Regular-webfont.woff?i=1", "Referer=https://rbcinsightbeta.rbc.com/ui/404?tv=1518029539410&prp=%2Fmain%2Freport%2F85997", ENDITEM, 
		LAST);

	web_custom_request("P1", 
		"URL=https://rbcinsightbeta.rbc.com/services/research/filecontent/85997/P1?tv=1518029557821", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://rbcinsightbeta.rbc.com/ui/main/report/85997", 
		"Snapshot=t34.inf", 
		"Mode=HTML", 
		"EncType=text/html", 
		EXTRARES, 
		"Url=/ui/assets/resources/images/ProfileIcon.png", "Referer=https://rbcinsightbeta.rbc.com/ui/main/report/85997", ENDITEM, 
		LAST);

	web_add_cookie("ak_bmsc={ak_bmsc_4}; DOMAIN=rbcinsightbeta.rbc.com");

	web_add_cookie("ak_bmsc={ak_bmsc_11}; DOMAIN=rbcinsightbeta.rbc.com");

	web_add_cookie("ak_bmsc={ak_bmsc_12}; DOMAIN=rbcinsightbeta.rbc.com");

	web_add_header("IS_ADMIN", 
		"false");

	web_add_header("Origin", 
		"https://rbcinsightbeta.rbc.com");

	web_add_header("iv-user", 
		"Kurt.Hallead@rbccm.com");

	web_custom_request("viewcallback", 
		"URL=https://rbcinsightbeta.rbc.com/services/analyst/analyst/viewcallback?tv=1518029560910", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://rbcinsightbeta.rbc.com/ui/main/report/85997", 
		"Snapshot=t35.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\n  \"user\": {\n    \"emailAddress\": \"Kurt.Hallead@rbccm.com\"\n  }\n}", 
		EXTRARES, 
		"Url=/assets/stylesheets/fonts/Light/Roboto-Light-webfont.woff?i=1", "Referer=https://rbcinsightbeta.rbc.com/ui/404?tv=1518029539410&prp=%2Fmain%2Freport%2F85997", ENDITEM, 
		"Url=/assets/stylesheets/fonts/Regular/FiraSans-Regular.woff2?i=1", "Referer=https://rbcinsightbeta.rbc.com/ui/404?tv=1518029539410&prp=%2Fmain%2Freport%2F85997", ENDITEM, 
		"Url=/ui/01-Offline.31301313641e3196177c.png", "Referer=https://rbcinsightbeta.rbc.com/ui/main/report/85997", ENDITEM, 
		LAST);

	lr_end_transaction("4_transaction_sparc_report",LR_AUTO);

	return 0;
}