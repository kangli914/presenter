Action()
{

	/* ORG
	web_set_sockets_option("SSL_VERSION", "TLS1.2");

	web_add_cookie("ak_bmsc=11D035BA0519A85B0958530B6C699F96B854F39EF27800004680785A65B1A305~plkpC3n0LE1H12j1l3mXj+uCbVGlSKvjZfmcPgS94xAT+JhFhDxujEePjnREaXGPXiCNdwetyGmsgaIivu+/fYbXOvjJn51Ly5neSa1vftZgl1m4U9CF8b4I1C9/wnsGJppoowSSisMtNGfR4TNa+JP8fXNVscPVfHP3uDL/af2aq9yGClplgCqj/ZndvRh/3fBhBeh4bo7RIvKYUxujOZp7xHMTOItKmfYsd8IMcWK1I=; DOMAIN=rbcinsightbeta.rbc.com");
	*/
	
	//web_set_sockets_option("SSL_VERSION", "TLS1.2");
	//web_set_sockets_option("SSL_VERSION", "2&3");
	web_set_max_html_param_len("500");
	
	web_add_cookie("IV_JCT={p_iv}; DOMAIN={domain}");
	web_add_cookie("deviceId={p_deviceid}; DOMAIN={domain}");
	web_add_cookie("PD-S-SESSION-ID={p_pd}; DOMAIN={domain}");
	web_add_cookie("TS01cc2b8b={p_ts}; DOMAIN={domain}");
	web_add_cookie("ak_bmsc={p_bmsc}; DOMAIN={domain}");

	web_add_auto_header("Upgrade-Insecure-Requests", "1");

	web_reg_save_param_regexp(
		"ParamName=ak_bmsc",
		"RegExp=ak_bmsc=(.*?);",
		SEARCH_FILTERS,
		"Scope=Cookies",
		"IgnoreRedirections=Yes",
		"RequestUrl=*/init.html*",
		LAST);
	
	//lr_start_transaction("MobileChrome_1_site");
		
	web_url("identifyUrself", 
		"URL=https://{domain}/ui/login/identifyUrself", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=../manifest.appcache", "Referer=", ENDITEM, 
		"Url=../app/common/Offline/css/fonts/fontawesome-webfont.woff2", "Referer=", ENDITEM, 
		"Url=../polyfills.9d2d4331ac6314df9952.bundle.js", "Referer=https://{domain}/ui/init.html?tv=1517846596162&prp=/login/identifyUrself", ENDITEM, 
		"Url=../styles.1989f6832538034aa979.bundle.css", "Referer=https://{domain}/ui/init.html?tv=1517846596162&prp=/login/identifyUrself", ENDITEM, 
		"Url=../inline.47bc698bc9775fafdd66.bundle.js", "Referer=https://{domain}/ui/init.html?tv=1517846596162&prp=/login/identifyUrself", ENDITEM, 
		"Url=../scripts.14fed4b49e163aac8f04.bundle.js", "Referer=https://{domain}/ui/init.html?tv=1517846596162&prp=/login/identifyUrself", ENDITEM, 
		"Url=../main.ef921c8758e1f4eafb65.bundle.js", "Referer=https://{domain}/ui/init.html?tv=1517846596162&prp=/login/identifyUrself", ENDITEM, 
		"Url=../app/common/Offline/IDRViewer/idrviewer.querystring-navigation.js", "Referer=", ENDITEM, 
		"Url=../vendor.4c388dfe32ea345522a0.bundle.js", "Referer=https://{domain}/ui/init.html?tv=1517846596162&prp=/login/identifyUrself", ENDITEM, 
		LAST);

	/* ORG:
	web_add_cookie("IV_JCT=%2Fui; DOMAIN={domain}");

	web_add_cookie("ak_bmsc=11D035BA0519A85B0958530B6C699F96B854F39EF27800004680785A65B1A305~plFwk+V9Cgn8KBQ6xZWB1yb5B41YfKYY+tlNFcadIXGUrZ4mMVnxXMgzZ8vEZJvZFru0rjtqi7x3BN8fDaFE140xKng8wAAiItzGEkc2t1uc1TIl8Hb4wcTNV1aK+z05WrbxxNQQ1WGlUFIgYUGMtplR5ER7XDzoh5KCzSzf/wfymQe13M/ZRzK2h4EjKOHB8ZqsnECIrYUBRTlRSTau1CaMzPwpsjzz6SBkxzWE3shBA=; DOMAIN={domain}");
	*/
	
	web_set_max_html_param_len("500");
	
	web_add_cookie("IV_JCT=%2Fui; DOMAIN={domain}");
	web_add_cookie("ak_bmsc={ak_bmsc}; DOMAIN={domain}");
	web_reg_save_param_regexp(
		"ParamName=ak_bmsc_1",
		"RegExp=ak_bmsc=(.*?);",
		SEARCH_FILTERS,
		"Scope=Cookies",
		"IgnoreRedirections=No",
		LAST);
	
	web_url("cache.html", 
		"URL=https://{domain}/ui/cache.html", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{domain}/ui/init.html?tv=1517846596162&prp=/login/identifyUrself", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=loading.c82062c113a7bcdafb57.gif", "Referer=https://{domain}/ui/init.html?tv=1517846596162&prp=/login/identifyUrself", ENDITEM, 
		"Url=app/common/Offline/IDRViewer/idrviewer.js", "Referer=", ENDITEM, 
		"Url=app/common/Offline/js/Highlight.js", "Referer=", ENDITEM, 
		LAST);

	/* ORG:
	web_add_cookie("TS01cc2b8b=0181cd863d6984effb233bb6010e2e77601648e7720d795e42e4a9a685c3dadc2f5568c0c9a2e0e7423de11be772e2dd6d14155c301265fab21c7640c82d3a3478b0913043; DOMAIN={domain}");

	web_add_cookie("PD-S-SESSION-ID=1_agsevBQuV3IT7Xvo7cS248KnwKoitkO5jxQvHApv7kYjfzgDrGA=_AAAAAAA=_9h77q3sTUQJ0Dl1l6fhXC8B5aQA=; DOMAIN={domain}");

	web_add_cookie("TS015371d2=0181cd863dd1b46a261fbcd57279a7fe72355026850d795e42e4a9a685c3dadc2f5568c0c96a4b2dd1b2c6c8a2dea8429bf11eda659ce6b9c930153c932953d0ab28d25dc3; DOMAIN={domain}");
	
	web_add_header("Origin", "https://{domain}");
	*/

	//web_revert_auto_header("Upgrade-Insecure-Requests");
	//web_set_max_html_param_len("1000");
	web_set_max_html_param_len("500");
	web_add_cookie("ak_bmsc={ak_bmsc_1}; DOMAIN={domain}");
	web_add_header("Origin", "https://{domain}");
	
	web_reg_find("Search=All",
		"Text/IC=\"statusCode\":\"DA1\"",
		LAST);

	web_custom_request("device", 
		"URL=https://{domain}/services/unauth/device", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://{domain}/ui/auth", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\n  \"timeZone\": \"America/Toronto\"\n}", 
		EXTRARES, 
		"Url=/ui/7.b53b92533528137ab907.chunk.js", "Referer=https://{domain}/ui/auth", ENDITEM, 
		"Url=/ui/app/common/Offline/js/handlebars-v4.js", "Referer=", ENDITEM, 
		"Url=/ui/0.18e83337367b0dc94aec.chunk.js", "Referer=https://{domain}/ui/auth", ENDITEM, 
		"Url=/ui/app/common/Offline/images/Alert.png", "Referer=", ENDITEM, 
		"Url=/ui/assets/stylesheets/fonts/Light/Roboto-Light-webfont.woff?i=1", "Referer=https://{domain}/ui/init.html?tv=1517846596162&prp=/login/identifyUrself", ENDITEM, 
		"Url=/ui/app/common/Offline/css/fonts/font-awesome.min.css", "Referer=", ENDITEM, 
		"Url=/ui/Logo_capital_markets.1213b6621dfd0ef82865.jpg", "Referer=https://{domain}/ui/login/identifyUrself", ENDITEM, 
		"Url=/ui/assets/stylesheets/fonts/Regular/Roboto-Regular-webfont.woff?i=1", "Referer=https://{domain}/ui/init.html?tv=1517846596162&prp=/login/identifyUrself", ENDITEM, 
		"Url=/ui/app/common/Offline/css/header.css", "Referer=", ENDITEM, 
		"Url=/ui/app/common/Offline/css/sparc.css", "Referer=", ENDITEM, 
		"Url=/ui/app/common/Offline/css/fonts/fontawesome-webfont.eot", "Referer=", ENDITEM, 
		"Url=/ui/app/common/Offline/pdfViewer/sinon-min.js", "Referer=", ENDITEM, 
		"Url=/ui/assets/stylesheets/fonts/fontawesome-webfont.woff2?v=4.7.0&i=1", "Referer=https://{domain}/ui/init.html?tv=1517846596162&prp=/login/identifyUrself", ENDITEM, 
		"Url=/ui/app/common/Offline/js/offlineDataStoreCommon.js", "Referer=", ENDITEM, 
		LAST);

	web_url("ViewReport.html", 
		"URL=https://{domain}/ui/app/common/Offline/ViewReport.html", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=css/fonts/FontAwesome.otf", "Referer=", ENDITEM, 
		"Url=css/fonts/fontawesome-webfont.svg", "Referer=", ENDITEM, 
		"Url=js/moment.js", "Referer=", ENDITEM, 
		"Url=css/fonts/fontawesome-webfont.ttf", "Referer=", ENDITEM, 
		"Url=images/Logo_capital_markets.jpg", "Referer=", ENDITEM, 
		"Url=css/fonts/fontawesome-webfont.woff", "Referer=", ENDITEM, 
		LAST);

	web_url("OfflineReport.html", 
		"URL=https://{domain}/ui/app/common/Offline/OfflineReport.html", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=css/fonts/fac.css", "Referer=", ENDITEM, 
		"Url=js/moment-timezone.js", "Referer=", ENDITEM, 
		"Url=images/Warning.png", "Referer=", ENDITEM, 
		LAST);

	//lr_end_transaction("MobileChrome_1_site",LR_AUTO);

	lr_think_time(5);	
		
	/*Possible OAUTH authorization was detected. It is recommended to correlate the authorization parameters.*/

	/* ORG:
	web_add_cookie("PD-S-SESSION-ID=1_agsevBQuV3IT7Xvo7cS248KnwKoitkO5jxQvHApv7kYjfzgDrGA=_AAAAAQA=_9h77q3sTUQJ0Dl1l6fhXC8B5aQA=; DOMAIN={domain}");

	web_add_cookie("TS015371d2=0181cd863da6b221fa80265dc327693c48218d3aed0d795e42e4a9a685c3dadc2f5568c0c9b78857a453573169619fa691fb71af41a2ea365c7bac6ea9bc206011811bb8aa; DOMAIN={domain}");

	web_add_header("DEVICE_NICKNAME", 
		"{p_device_nickname}");

	web_add_header("EMAIL_ADDRESS", 
		"{p_email}");

	web_add_header("Origin", 
		"https://{domain}");
	*/

	web_add_header("DEVICE_NICKNAME", "{p_device_nickname}");
	web_add_header("EMAIL_ADDRESS", "{p_email}");
	web_add_header("Origin", "https://{domain}");	
	web_reg_save_param_regexp(
		"ParamName=ak_bmsc_2",
		"RegExp=ak_bmsc=(.*?);",
		SEARCH_FILTERS,
		"Scope=Cookies",
		"IgnoreRedirections=No",
		LAST);
		
	web_reg_find("Search=All", "Text=userId", LAST);

	//lr_start_transaction("MobileChrome_2_email");
		
	web_custom_request("email", 
		"URL=https://{domain}/services/auth/email", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://{domain}/ui/login/identifyUrself", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={}", 
		EXTRARES, 
		"Url=/ui/glyphicons-halflings-regular.448c34a56d699c29117a.woff2", "Referer=https://{domain}/ui/init.html?tv=1517846596162&prp=/login/identifyUrself", ENDITEM, 
		"Url=https://cl2.apple.com/3/v1/132/100/1320000_1000000_00000000012E01EA.gz", "Referer=", ENDITEM, 
		LAST);

	//lr_end_transaction("MobileChrome_2_email",LR_AUTO);
	
	lr_think_time(5);
	
	/* ORG:
	web_add_cookie("ak_bmsc=A25E2AC34B1A47BA8438D1C11D1D0B41B854F39EF2780000A280785A2D8E423A~plHa6NMMKTByI3mUHigk/3ToARkli2FQ450aBCuDEv74KdU8AEQ7BTvTyJ//tINlhV45XHbWCaVbFblJQb5EdcbanM+cUPh4SSwkCksPSTiE5Uot5tGH/1lPLPm4N8g+PPXDakP60V7PZVo1Gq4A4ejP5ZQFJaPsjj3AefFLXubHWGYebo7LwIjEYdQK6IMOqSBa8UeVDxKXXNQ76ssp5wztXwbfx+IQCfO8S/TyO5rZA=; DOMAIN={domain}");

	web_add_header("X-Requested-With", 
		"XMLHttpRequest");

	web_custom_request("healthcheck", 
		"URL=https://{domain}/services/auth/healthcheck?tv=1517846722212", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://{domain}/ui/login/authenticateUser", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		LAST);
	*/
	
	/* ORG
	lr_think_time(5);
	
	web_add_cookie("ak_bmsc=A25E2AC34B1A47BA8438D1C11D1D0B41B854F39EF2780000A280785A2D8E423A~plc5Oc76Cg4m3yt3cfvK9vTIViYKmKPtfMzLVwGAoK8t8Mn68/TcfsCmO7J4VMa68v1a9qgbRpPRGR5KnllUz0qtRRUIh3u9D8AluWUGctwVbBU+/w9Z+5aDkXw2/YhwTphq+iVW8mR9mt7nWCRO1oFvU/Bjcaixhcai6Y7igHfGh31XV8rm96KaTX/43gw05oeLi2StQo4yttKdwe2GuTD0lxndtodn4jbYcZs97Fun0=; DOMAIN={domain}");

	web_add_cookie("ak_bmsc=11D035BA0519A85B0958530B6C699F96B854F39EF27800004680785A65B1A305~plEIfWr+64OYHMZyNZIrHpnbl77wbBg8hSNKXIWEQLt9UTYrIg/gs0qB0FbXPpsW6oXT+aNsX4+c1NVz7KEmfz30Hepolidm7NUrxbCoE6nEdezTHtFdODAm+lGU8BrbJRPXQhDe7V3uDH8UzsGpZgDRkTnsTA899IFnq3L6RjHHrxSKlQ+ns3cCEcmS5+l44Tp54LVXPYbjjlNv+N9v9eD8P27jYmkzkjZX0JmM8si+M=; DOMAIN={domain}");

	web_add_cookie("PD-S-SESSION-ID=1_agsevBQuV3IT7Xvo7cS248KnwKoitkO5jxQvHApv7kYjfzgDrGA=_AAAAAgA=_9h77q3sTUQJ0Dl1l6fhXC8B5aQA=; DOMAIN={domain}");

	web_add_cookie("TS015371d2=0181cd863da1f6e8167639a9556e19dd0b7e7708a60d795e42e4a9a685c3dadc2f5568c0c99c27269b58c41cf47847f16ff5cfe93d20dc8caf01ab024fd23b45a48c8e84e8; DOMAIN={domain}");
	
	web_add_header("ACCESS_KEY", 
		"{p_accesskey}");

	web_add_header("DEVICE_NICKNAME", 
		"SH - {p_device_nickname}003");

	web_add_header("Origin", "https://{domain}");
	*/

	web_add_cookie("ak_bmsc={ak_bmsc_2}; DOMAIN={domain}");
	web_add_header("ACCESS_KEY", "{p_accesskey}");
	web_add_header("DEVICE_NICKNAME", "SH - {p_device_nickname}{p_device_num}{p_device_num}");
	web_add_header("Origin", "https://{domain}");
		
	web_reg_find("Search=All", "Text/IC=\"statusCode\":\"AA0\"", LAST);

	//lr_start_transaction("MobileChrome_3_keysubmit-Home_Dashboard_Load");

	web_custom_request("accesskey", 
		"URL=https://{domain}/services/auth/accesskey", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://{domain}/ui/login/authenticateUser", 
		"Snapshot=t16.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\n  \"timeZone\": \"America/Toronto\"\n}", 
		EXTRARES, 
		"Url=/ui/6.8fe1aa239f69a522da2d.chunk.js", "Referer=https://{domain}/ui/login/authenticateUser", ENDITEM, 
		"Url=/ui/assets/resources/images/ProfileIcon.png", "Referer=https://{domain}/ui/main/dashboard", ENDITEM, 
		"Url=/ui/searchpane-3.3ea695f6dbea633dd655.jpg", "Referer=https://{domain}/ui/main/dashboard", ENDITEM, 
		"Url=/ui/assets/resources/images/Logo_capital_markets.jpg", "Referer=https://{domain}/ui/main/dashboard", ENDITEM, 
		LAST);

	web_url("frequentanalyst", 
		"URL=https://{domain}/services/gresearch/frequentanalyst?tv=1517846740588", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://{domain}/ui/main/dashboard", 
		"Snapshot=t17.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Origin", "https://{domain}");

	web_custom_request("data", 
		"URL=https://{domain}/services/research/event/data?tv=1517846740738", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://{domain}/ui/main/dashboard", 
		"Snapshot=t18.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\n  \"pageIndex\": 0,\n  \"batchSize\": 5,\n  \"eventSearchCriteria\": {\n    \"eventTypeList\": null,\n    \"locationList\": null,\n    \"regionIdList\": null,\n    \"fromDate\": \"5/2/2018\",\n    \"sortBy\": 0,\n    \"sortType\": 1\n  }\n}", 
		LAST);

	web_custom_request("data_2", 
		"URL=https://{domain}/services/gresearch/module/data?tv=1517846740793", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://{domain}/ui/main/dashboard", 
		"Snapshot=t19.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\n  \"pageIndex\": 0,\n  \"batchSize\": 5,\n  \"researchModuleId\": 32172,\n  \"searchCriteria\": {\n    \"dateRange\": 1,\n    \"fromDate\": null,\n    \"toDate\": null,\n    \"reportType\": 1,\n    \"contentType\": 0,\n    \"sortBy\": 4,\n    \"sortType\": 2,\n    \"keywordText\": \"\",\n    \"keywordSearchType\": 1,\n    \"actionType\": []\n  }\n}", 
		LAST);

	web_custom_request("data_3", 
		"URL=https://{domain}/services/gresearch/module/data?tv=1517846740790", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://{domain}/ui/main/dashboard", 
		"Snapshot=t20.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\n  \"pageIndex\": 0,\n  \"batchSize\": 5,\n  \"researchModuleId\": 32167,\n  \"searchCriteria\": {\n    \"dateRange\": 1,\n    \"fromDate\": null,\n    \"toDate\": null,\n    \"reportType\": 1,\n    \"contentType\": 0,\n    \"sortBy\": 4,\n    \"sortType\": 2,\n    \"keywordText\": \"\",\n    \"keywordSearchType\": 1,\n    \"actionType\": []\n  }\n}", 
		LAST);

	web_custom_request("data_4", 
		"URL=https://{domain}/services/gresearch/module/data?tv=1517846740796", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://{domain}/ui/main/dashboard", 
		"Snapshot=t21.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\n  \"pageIndex\": 0,\n  \"batchSize\": 5,\n  \"researchModuleId\": 32177,\n  \"searchCriteria\": {\n    \"dateRange\": 1,\n    \"fromDate\": null,\n    \"toDate\": null,\n    \"reportType\": 1,\n    \"contentType\": 0,\n    \"sortBy\": 4,\n    \"sortType\": 2,\n    \"keywordText\": \"\",\n    \"keywordSearchType\": 1,\n    \"actionType\": []\n  }\n}", 
		LAST);

	/* ORG:
	web_add_cookie("ak_bmsc=11D035BA0519A85B0958530B6C699F96B854F39EF27800004680785A65B1A305~plno9vCI65ynFaROTaOT92clMUSj8tnVDOSiTaDjYwVvfs0w+eKgDUYLYWiufvaCoNhTEZmsAdfk0HdWZL05dzK8T9PTVFXcKVIsHlOX+eoM7UFFDMfLjJ69ah8NCM4sdFjIHTeh/ordafeI5x7MVxa6o9pJxNBDs9lTC/DqURR7d8k6+5EbXu2iJd2GVcZoZhyLKNMa6PofkKWj44V3x5F+Wr8Kv/uSbzming5rkKzX0=; DOMAIN={domain}");

	web_add_cookie("ak_bmsc=11D035BA0519A85B0958530B6C699F96B854F39EF27800004680785A65B1A305~plUXeJ5gqKy8c0005nAiFCQHGlwuMOHCi7bAaqk/N1CbFIqNPBuQGXrWURNKcCxzw4u/24peRs/a+cYFkljcai1rG2+Z2Yqn2JJl3IGYgHTixWBYJzJHyMfYX1dI+mJCWvCzdXFHZCGgIy2MeiT3nwB6GTHviZYT7lTpmjLgKQi56kabZCrKZj/fGd6c+ItXezZpGti5byQiCQLKoRR/0dx+sZ7GOQixCpYlaM+fSIZhg=; DOMAIN={domain}");
	*/
	
	web_custom_request("data_5", 
		"URL=https://{domain}/services/gresearch/module/data?tv=1517846740795", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://{domain}/ui/main/dashboard", 
		"Snapshot=t22.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\n  \"pageIndex\": 0,\n  \"batchSize\": 5,\n  \"researchModuleId\": 32175,\n  \"searchCriteria\": {\n    \"dateRange\": 1,\n    \"fromDate\": null,\n    \"toDate\": null,\n    \"reportType\": 1,\n    \"contentType\": 0,\n    \"sortBy\": 4,\n    \"sortType\": 2,\n    \"keywordText\": \"\",\n    \"keywordSearchType\": 1,\n    \"actionType\": []\n  }\n}", 
		EXTRARES, 
		"Url=/ui/assets/stylesheets/fonts/Regular/FiraSans-Regular.woff2?i=1", "Referer=https://{domain}/ui/init.html?tv=1517846596162&prp=/login/identifyUrself", ENDITEM, 
		LAST);

	/* ORG:
	web_add_cookie("ak_bmsc=2E0BDD7EF9EF8940FF272CCE4D290C3648F62B8DEB280000D580785AF8EE9B74~pl45sR7rAcs+Dlb1FRPc4NVN6hBRff6m7sVnq2l7QvKcUq9Jh3cY7m1nlO7cP5bQMsQvzjVEV/gL1T02rIxtps8hLLPOgd5mQZglDUhLbJVzePG+g73GWZGfPVCNpwRelpiVayMk1xD0qnpYXTrl9HGl8/gLWWYbnAwmViZfTQSlirGBPCH9uSQ51gasPJrxZ0J+zyfIDk19S7iF61eJhtoF5eOnkOj/tRKg+DMetyNOc=; DOMAIN={domain}");
	*/
	
	web_custom_request("data_6", 
		"URL=https://{domain}/services/gresearch/module/data?tv=1517846740794", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://{domain}/ui/main/dashboard", 
		"Snapshot=t23.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\n  \"pageIndex\": 0,\n  \"batchSize\": 5,\n  \"researchModuleId\": 32174,\n  \"searchCriteria\": {\n    \"dateRange\": 1,\n    \"fromDate\": null,\n    \"toDate\": null,\n    \"reportType\": 1,\n    \"contentType\": 0,\n    \"sortBy\": 4,\n    \"sortType\": 2,\n    \"keywordText\": \"\",\n    \"keywordSearchType\": 1,\n    \"actionType\": []\n  }\n}", 
		LAST);

	web_custom_request("data_7", 
		"URL=https://{domain}/services/gresearch/module/data?tv=1517846740792", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://{domain}/ui/main/dashboard", 
		"Snapshot=t24.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\n  \"pageIndex\": 0,\n  \"batchSize\": 5,\n  \"researchModuleId\": 32169,\n  \"searchCriteria\": {\n    \"dateRange\": 1,\n    \"fromDate\": null,\n    \"toDate\": null,\n    \"reportType\": 1,\n    \"contentType\": 0,\n    \"sortBy\": 4,\n    \"sortType\": 2,\n    \"keywordText\": \"\",\n    \"keywordSearchType\": 1,\n    \"actionType\": []\n  }\n}", 
		LAST);

	/* ORG
	web_add_cookie("ak_bmsc=11D035BA0519A85B0958530B6C699F96B854F39EF27800004680785A65B1A305~plIP2TQyIOMODV+peYevmwV5jQaUKKfJ8hPL0r2jkXCyfueYsgqwqnlunh3TFPbU/l2Ad/2bPDaI2Nqa6uRG+gkhaJEIBbhPJHW66fBxha/Yt1V+JwiQAoCNEWYHxXfbaOsTHMLonY2eImd/zj8dBizyS8igHl/CzLVrF7aB8a14YrGa6Pigp62lMFvYBCv8A7B1BfxEVkzTKg4W7OTkAJwURRk8YcIKtY5jnjUor+UK8=; DOMAIN={domain}");
	*/
		
	web_custom_request("data_8", 
		"URL=https://{domain}/services/gresearch/module/data?tv=1517846740789", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://{domain}/ui/main/dashboard", 
		"Snapshot=t25.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\n  \"pageIndex\": 0,\n  \"batchSize\": 5,\n  \"researchModuleId\": 32165,\n  \"searchCriteria\": {\n    \"dateRange\": 1,\n    \"fromDate\": null,\n    \"toDate\": null,\n    \"reportType\": 1,\n    \"contentType\": 0,\n    \"sortBy\": 4,\n    \"sortType\": 2,\n    \"keywordText\": \"\",\n    \"keywordSearchType\": 1,\n    \"actionType\": []\n  }\n}", 
		EXTRARES, 
		"Url=/ui/assets/stylesheets/fonts/Regular/Roboto-Medium-webfont.woff?i=1", "Referer=https://{domain}/ui/init.html?tv=1517846596162&prp=/login/identifyUrself", ENDITEM, 
		LAST);

	web_revert_auto_header("Origin");
	web_add_header("iv-user", "{p_email}");
	web_reg_save_param_regexp(
		"ParamName=ak_bmsc_3",
		"RegExp=ak_bmsc=(.*?);",
		SEARCH_FILTERS,
		"Scope=Cookies",
		"IgnoreRedirections=No",
		LAST);
	
	web_url("list", 
		"URL=https://{domain}/services/common/banner/list?tv=1517846740639", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://{domain}/ui/main/dashboard", 
		"Snapshot=t26.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=../bannerimages/2.png?nocache=1517846740595", "Referer=https://{domain}/ui/main/dashboard", ENDITEM, 
		"Url=../bannerimages/3.png?nocache=1517846740595", "Referer=https://{domain}/ui/main/dashboard", ENDITEM, 
		"Url=/ui/assets/resources/images/trending.gif", "Referer=https://{domain}/ui/main/dashboard", ENDITEM, 
		"Url=../bannerimages/17.png?nocache=1517846740595", "Referer=https://{domain}/ui/main/dashboard", ENDITEM, 
		LAST);

	//lr_end_transaction("MobileChrome_3_keysubmit-Home_Dashboard_Load",LR_AUTO);

	lr_think_time(5);

	//web_add_cookie("ak_bmsc=A25E2AC34B1A47BA8438D1C11D1D0B41B854F39EF2780000A280785A2D8E423A~plnhxXvyysVSKJe16G5XSmRAi9oR4Jx2AoytDaVlQ3Esb1R1cPbWHgB0Coh1wnvVtOk17giB2PleNRmYlYuv4vfMWI2D6+Z+3o6qqMoQ40CQzL4efmKiC8lpA9u4iy7OHCSBIV01eGapTdxlH+7AQ3yNk3G0amzODA5HgXC9YuMRYc6NaEiYfKoWE/ASUGL6dMbYTFh4dwVoyzJAXWURJtKP3XIATbTjQ5WhK/2Cst02c=; DOMAIN={domain}");

	/*
	web_add_header("X-Requested-With", "XMLHttpRequest");

	web_custom_request("healthcheck_2", 
		"URL=https://{domain}/services/auth/healthcheck?tv=1517846842210", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://{domain}/ui/main/dashboard", 
		"Snapshot=t28.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		LAST);
	*/
	
	//web_add_cookie("ak_bmsc=11D035BA0519A85B0958530B6C699F96B854F39EF27800004680785A65B1A305~plUSdraM0nmF4CMpiilO6F8iaVH+AI3eAtdRT9+tZfC5PolU5Q+aXv1MQ9FF+UVS4eZct5x6BuDcbUPTLPEMFjShPuND+bayunf2xU+MddS2S3k9uNZZqvWsjsDCUTp5iQftOGFBW6fm16qWMirPYB833odWZqIa7nJO0KmAroYODUqywcnwY6qZ6MvbYz+gWv5Tg5JvkB1P2t599VYSuchyIaR+eLR6EkD74UNpvr3sg=; DOMAIN={domain}");

	web_add_cookie("ak_bmsc={ak_bmsc_3}; DOMAIN={domain}");
	//lr_start_transaction("MobileChrome_4_BM-CanadianBankChartBook_Report");
	
	web_url("main/report_0ccba1fb-2b51-42a3-a695-4f13ec3e482c", 
		"URL=https://{domain}/ui/main/report/0ccba1fb-2b51-42a3-a695-4f13ec3e482c", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t29.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/ui/styles.1989f6832538034aa979.bundle.css", "Referer=https://{domain}/ui/init.html?tv=1517846848094&prp=/main/report/0ccba1fb-2b51-42a3-a695-4f13ec3e482c", ENDITEM, 
		"Url=/ui/inline.47bc698bc9775fafdd66.bundle.js", "Referer=https://{domain}/ui/init.html?tv=1517846848094&prp=/main/report/0ccba1fb-2b51-42a3-a695-4f13ec3e482c", ENDITEM, 
		"Url=/ui/polyfills.9d2d4331ac6314df9952.bundle.js", "Referer=https://{domain}/ui/init.html?tv=1517846848094&prp=/main/report/0ccba1fb-2b51-42a3-a695-4f13ec3e482c", ENDITEM, 
		"Url=/ui/manifest.appcache", "Referer=", ENDITEM, 
		"Url=/ui/scripts.14fed4b49e163aac8f04.bundle.js", "Referer=https://{domain}/ui/init.html?tv=1517846848094&prp=/main/report/0ccba1fb-2b51-42a3-a695-4f13ec3e482c", ENDITEM, 
		"Url=/ui/main.ef921c8758e1f4eafb65.bundle.js", "Referer=https://{domain}/ui/init.html?tv=1517846848094&prp=/main/report/0ccba1fb-2b51-42a3-a695-4f13ec3e482c", ENDITEM, 
		"Url=/ui/vendor.4c388dfe32ea345522a0.bundle.js", "Referer=https://{domain}/ui/init.html?tv=1517846848094&prp=/main/report/0ccba1fb-2b51-42a3-a695-4f13ec3e482c", ENDITEM, 
		"Url=/ui/loading.c82062c113a7bcdafb57.gif", "Referer=https://{domain}/ui/init.html?tv=1517846848094&prp=/main/report/0ccba1fb-2b51-42a3-a695-4f13ec3e482c", ENDITEM, 
		LAST);

	web_url("cache.html_2", 
		"URL=https://{domain}/ui/cache.html", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{domain}/ui/init.html?tv=1517846848094&prp=/main/report/0ccba1fb-2b51-42a3-a695-4f13ec3e482c", 
		"Snapshot=t30.inf", 
		"Mode=HTML", 
		LAST);

	//web_add_cookie("ak_bmsc=7956A8B9592CA20F68127BC4BE693B69B854F39EF27800004B80785AFCE86B46~pltBvPRVU6A8Qq7nnR6Iaak05Ay1E51bqOBKnNekpT4iAv2pCiBzMv4A09iWJyxwUYQgSEhyiWq9l0q6uRPB/zw0FdlWS3IzATq7+fmoCHj8FKZ0dy7PAnQfbZyTFLGET7Xv5V9LfzgKfcKc6JazBPz8/+AFCG1Go0DkM9zdi08abt2VOvg6y6si1njyQVul1y8ly6vi2FGMISQbhUWL9VdAngWY11/mcW418ZoIkhEog=; DOMAIN={domain}");

	//web_add_cookie("ak_bmsc=11D035BA0519A85B0958530B6C699F96B854F39EF27800004680785A65B1A305~plEoulNzt9dZAuBaebM4r6tMgocqPn/LGhkVCvTp9jjCIms6Q/xushI3xnB1n5Tl9VvxCrHTqFubo757thSBVNLlHF+FRLiVNhJUs9Qf+7+bp+rbEvm1M7jlvvUpMoCz4550FmSlJtKflpfZMEBoFjaANuUKxlv669eSXk9fVmjJgpY05UJonL58UhuVGYXCpDM4I1pOGYf6Rs/nC/0tm00xQk4Gw0ceqaSp6xfYtVd08=; DOMAIN={domain}");

	//web_add_cookie("PD-S-SESSION-ID=1_agsevBQuV3IT7Xvo7cS248KnwKoitkO5jxQvHApv7kYjfzgDrGA=_AAAAAwA=_9h77q3sTUQJ0Dl1l6fhXC8B5aQA=; DOMAIN={domain}");

	//web_add_cookie("TS015371d2=0181cd863d98400955e39502f10965721faaa29f760d795e42e4a9a685c3dadc2f5568c0c9611e10d52985ebac05cde5233f8ec631023c2a86767782e1165e438187ae130f; DOMAIN={domain}");

	//web_add_auto_header("Origin", "https://{domain}");

	web_reg_find("Search=All",
		"Text/IC=\"statusCode\":\"DA0\"",
		LAST);

	web_custom_request("device_2", 
		"URL=https://{domain}/services/unauth/device", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://{domain}/ui/auth", 
		"Snapshot=t31.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\n  \"timeZone\": \"America/Toronto\"\n}", 
		EXTRARES, 
		"Url=/ui/0.18e83337367b0dc94aec.chunk.js", "Referer=https://{domain}/ui/auth", ENDITEM, 
		"Url=/ui/6.8fe1aa239f69a522da2d.chunk.js", "Referer=https://{domain}/ui/auth", ENDITEM, 
		"Url=/ui/1.535bbaf4764fbb020d9f.chunk.js", "Referer=https://{domain}/ui/auth", ENDITEM, 
		LAST);

	web_custom_request("research/metadata", 
		"URL=https://{domain}/services/research/metadata/0ccba1fb-2b51-42a3-a695-4f13ec3e482c/0/null?tv=1517846855141", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://{domain}/ui/auth", 
		"Snapshot=t32.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={}", 
		EXTRARES, 
		"Url=/ui/assets/resources/images/ProfileIcon.png", "Referer=https://{domain}/ui/main/report/0ccba1fb-2b51-42a3-a695-4f13ec3e482c", ENDITEM, 
		"Url=/ui/assets/resources/images/Logo_capital_markets.jpg", "Referer=https://{domain}/ui/main/report/0ccba1fb-2b51-42a3-a695-4f13ec3e482c", ENDITEM, 
		"Url=/ui/searchpane-3.3ea695f6dbea633dd655.jpg", "Referer=https://{domain}/ui/main/report/0ccba1fb-2b51-42a3-a695-4f13ec3e482c", ENDITEM, 
		LAST);
		

	//web_revert_auto_header("Origin");

	//web_add_cookie("ak_bmsc=11D035BA0519A85B0958530B6C699F96B854F39EF27800004680785A65B1A305~pljLSwhhqtWBQYfJBPGp8EIER2ddapijWblaRZY4f+LiSUdUflD6edlPDyHldpHeVlzif8xKGLlv183Kh5IP5w2WwbXR7EQqMNhhmG3GoGBlCQ4hAwLUNB2/L7OrP8OV4QvVmDRKJ5n/igxjnV2grmT8avgFI0NB2kwsNRhcmelQ8foV62GmZBTnZ2XvJf8jhzSxilPR1yPG/fuJAKKfjELaDmdjpMRa5KkaBEdAvxRn4=; DOMAIN={domain}");

	web_reg_find("Search=All", "Text/IC=\"statusCode\":\"RD0\"", LAST);

	web_reg_find("Search=All", "Text/IC=researchDocumentId", LAST);

	web_url("recommended/data_0ccba1fb-2b51-42a3-a695-4f13ec3e482c", 
		"URL=https://{domain}/services/gresearch/recommended/data/0ccba1fb-2b51-42a3-a695-4f13ec3e482c?tv=1517846856599", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://{domain}/ui/main/report/0ccba1fb-2b51-42a3-a695-4f13ec3e482c", 
		"Snapshot=t33.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/ui/04-Offline.7678760de440ce88bc46.png", "Referer=https://{domain}/ui/main/report/0ccba1fb-2b51-42a3-a695-4f13ec3e482c", ENDITEM, 
		"Url=/ui/assets/stylesheets/fonts/Regular/Roboto-Medium-webfont.woff?i=1", "Referer=https://{domain}/ui/init.html?tv=1517846848094&prp=/main/report/0ccba1fb-2b51-42a3-a695-4f13ec3e482c", ENDITEM, 
		LAST);

	web_url("research/content_2", 
		"URL=https://{domain}/services/research/content/0ccba1fb-2b51-42a3-a695-4f13ec3e482c/2/1", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://{domain}/ui/main/report/0ccba1fb-2b51-42a3-a695-4f13ec3e482c", 
		"Snapshot=t34.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/ui/assets/stylesheets/fonts/fontawesome-webfont.woff2?v=4.7.0&i=1", "Referer=https://{domain}/ui/init.html?tv=1517846848094&prp=/main/report/0ccba1fb-2b51-42a3-a695-4f13ec3e482c", ENDITEM, 
		LAST);

	//web_add_cookie("ak_bmsc=11D035BA0519A85B0958530B6C699F96B854F39EF27800004680785A65B1A305~pljCjW4VN0Droh0T85WXUvh2OdJwJ4AOkPhtzPAgfiznq/9VfG35vjy9BGQWHbdwClbKF22kx57isiW/4xKz5lsn1KmGCN3OcB413x1TbRdm+ifVuBiKj+gK6/o98nMyCxSB1MqSmwmu2Pjv248Yib8G8lY0QRG0xxcJO8rPbJJs/qNdIdDsSAGUeT9RED+k86LO8FFPq+2627uP5vtSfssHDtEFatGQpQs//Z/OyBN4g=; DOMAIN={domain}");

	//web_add_cookie("ak_bmsc=11D035BA0519A85B0958530B6C699F96B854F39EF27800004680785A65B1A305~pl+MUImmalhk43lwHBpJsfVxvAZIEMThUraW26+5XYXKg3zgn+q9sv9YOYTtzmBF2gvm1Ndsq5pdFvcc4KBxPXF4kwONPRReQFz3vL/ftQnzSezDT1AgYPFusENvRfeZoND+4Hoy8ZKawlkyH9Yd4pXfI+ZJIwBjSP6xtXoeiMhdHNEadKvhnQToAbqkU5y8aBwJIKvzegmuj47pc4b4Gz31U57SKsS/ii74G3XB29L4Q=; DOMAIN={domain}");

	//web_add_cookie("ak_bmsc=11D035BA0519A85B0958530B6C699F96B854F39EF27800004680785A65B1A305~plQrhRz2lSw50uBn/qUrezGMKQ962HmRTF3sH6CWjx96nSVdlGIimcgadncvNMbGnFZJp1GO+ZXdUkWVS40cy6b3ePXldwk6hHfRN8vNyUrnf6FLwWlEewvrdN+yLgLgEroQ4rOtFF6XXS+QDbytNqM79SY/qM3JvVp6exCyHfLhEy/n6zlO10Xfz/3218ynHbEPl4hv8yBCqLyiChMrgwCvrcSauVbaTiVCnc0LsxXPI=; DOMAIN={domain}");

	web_url("research/content_3", 
		"URL=https://{domain}/services/research/content/0ccba1fb-2b51-42a3-a695-4f13ec3e482c/3/1", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://{domain}/ui/main/report/0ccba1fb-2b51-42a3-a695-4f13ec3e482c", 
		"Snapshot=t35.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/ui/assets/stylesheets/fonts/Regular/FiraSans-Regular.woff2?i=1", "Referer=https://{domain}/ui/init.html?tv=1517846848094&prp=/main/report/0ccba1fb-2b51-42a3-a695-4f13ec3e482c", ENDITEM, 
		LAST);

	web_url("research/content_4", 
		"URL=https://{domain}/services/research/content/0ccba1fb-2b51-42a3-a695-4f13ec3e482c/4/1", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://{domain}/ui/main/report/0ccba1fb-2b51-42a3-a695-4f13ec3e482c", 
		"Snapshot=t36.inf", 
		"Mode=HTML", 
		LAST);

	web_url("research/content_5", 
		"URL=https://{domain}/services/research/content/0ccba1fb-2b51-42a3-a695-4f13ec3e482c/5/1", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://{domain}/ui/main/report/0ccba1fb-2b51-42a3-a695-4f13ec3e482c", 
		"Snapshot=t37.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/ui/assets/stylesheets/fonts/Regular/Roboto-Regular-webfont.woff?i=1", "Referer=https://{domain}/ui/init.html?tv=1517846848094&prp=/main/report/0ccba1fb-2b51-42a3-a695-4f13ec3e482c", ENDITEM, 
		LAST);

	web_url("research/content_7", 
		"URL=https://{domain}/services/research/content/0ccba1fb-2b51-42a3-a695-4f13ec3e482c/7/1", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://{domain}/ui/main/report/0ccba1fb-2b51-42a3-a695-4f13ec3e482c", 
		"Snapshot=t38.inf", 
		"Mode=HTML", 
		LAST);

	web_url("research/content_6", 
		"URL=https://{domain}/services/research/content/0ccba1fb-2b51-42a3-a695-4f13ec3e482c/6/1", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://{domain}/ui/main/report/0ccba1fb-2b51-42a3-a695-4f13ec3e482c", 
		"Snapshot=t39.inf", 
		"Mode=HTML", 
		LAST);

	web_url("research/content_8", 
		"URL=https://{domain}/services/research/content/0ccba1fb-2b51-42a3-a695-4f13ec3e482c/8/1", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://{domain}/ui/main/report/0ccba1fb-2b51-42a3-a695-4f13ec3e482c", 
		"Snapshot=t40.inf", 
		"Mode=HTML", 
		LAST);

	web_url("research/content_9", 
		"URL=https://{domain}/services/research/content/0ccba1fb-2b51-42a3-a695-4f13ec3e482c/9/1", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://{domain}/ui/main/report/0ccba1fb-2b51-42a3-a695-4f13ec3e482c", 
		"Snapshot=t41.inf", 
		"Mode=HTML", 
		LAST);

	web_url("research/content_10", 
		"URL=https://{domain}/services/research/content/0ccba1fb-2b51-42a3-a695-4f13ec3e482c/10/1", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://{domain}/ui/main/report/0ccba1fb-2b51-42a3-a695-4f13ec3e482c", 
		"Snapshot=t42.inf", 
		"Mode=HTML", 
		LAST);

	//lr_end_transaction("MobileChrome_4_BM-CanadianBankChartBook_Report",LR_AUTO);

	return 0;
}